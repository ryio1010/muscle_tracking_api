select
    *
from
    m_user
;