select
    *
from
    m_user u
where
    u.uname=/* userName */'aaa'