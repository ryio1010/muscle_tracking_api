package com.muscle_tracking_api.MuscleTrackingApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MuscleTrackingApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MuscleTrackingApiApplication.class, args);
	}

}
