package com.muscle_tracking_api.MuscleTrackingApi;

public class AppConfig {
}
