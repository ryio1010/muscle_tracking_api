package com.muscle_tracking_api.MuscleTrackingApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MuscleTrackingApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
